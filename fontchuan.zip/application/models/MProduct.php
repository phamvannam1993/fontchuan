<?php

class MProduct extends CI_Model {
    protected $table;

    function __construct() {
        parent::__construct();
        $this->table = "products";
    }

    public function insert($data = []) {
        $data["created_at"] = date('Y-m-d H:i:s');
        $data["updated_at"] = date('Y-m-d H:i:s');
        $this->db->insert($this->table, $data);
        return $this->db->insert_id();
    }

    function update($id, $data = []) {
        $data['updated_at'] = date('Y-m-d H:i:s');
        $this->db->where(["id" => $id])->update($this->table, $data);
    }

    public function delete($id) {
        return $this->db->where(["id" => $id])->delete($this->table);
    }

    public function getOneByID($id) {
        $this->db->select('*')->where(["id" => $id]);
        $this->db->from($this->table);
        return $this->db->get()->row_array();
    }

    public function getOneBy($params = []) {
        $query = $this->db->select('*');
        if(isset($params["id"])) {
            $query = $query->where(["id" => $params["id"]]);
        } 
        if(isset($params["name"])) {
            $query = $query->where(["name" => $params["name"]]);
        }
        
        if(isset($params["slug"])) {
            $query = $query->where(["slug" => $params["slug"]]);
        }
        $query->from($this->table);
        return  $query->get()->row();
    }

    public function get($params = []) {
        $this->db->select('*');
        $this->db->from($this->table);
        if(isset($params["limit"]) && isset($params["offset"]))  {
            $this->db->limit($params["limit"], $params["offset"]);
        }
        if(isset($params["search"]))  {
            $this->db->like("name", $params["search"]);
        }
        if(isset($params["is_popular"]))  {
            $this->db->where("is_popular", $params["is_popular"]);
        }
        if(isset($params["category_id"]))  {
            $this->db->where("category_id", $params["category_id"]);
        }
        $this->db->order_by('id', 'DESC');
        return $this->db->get()->result_array();
    }
    public function get_by($params) {
        $query = $this->db->select('*');
        if ($params != '') {
            $query = $query->where($params);
        }
        $query->from($this->table);
        return  $query->get()->row();
    }

    public function count_all()
    {
        return $this->db->count_all($this->table);
    }

    public function get_data($limit, $offset)
    {
        return $this->db->limit($limit, $offset)->get($this->table)->result();
    }

    public function getPopular() {
        return [
            [
                'id' => 1,
                'name' => 'Phổ biến'
            ],
            [
                'id' => 0,
                'name' => 'Không phổ biến'
            ],
        ];
    }

    public function getAddress() {
        return [
            [
                'id' => 1,
                'name' => 'Hà Nội'
            ],
            [
                'id' => 2,
                'name' => 'Hồ Chí Minh'
            ],
            [
                'id' => 3,
                'name' => 'Hà Nội và Hồ Chí Minh'
            ],
        ];
    }
}

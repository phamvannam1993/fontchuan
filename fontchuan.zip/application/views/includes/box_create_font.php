<div class="elementor-element elementor-element-7df9a9d e-flex e-con-boxed e-con e-parent" data-id="7df9a9d" data-element_type="container" data-settings='{"background_background":"classic"}'>
    <div class="e-con-inner">
        <div class="elementor-element elementor-element-26b8769 e-con-full e-flex e-con e-child" data-id="26b8769" data-element_type="container" data-settings='{"background_background":"classic"}'>
            <div class="elementor-element elementor-element-ca0392a elementor-widget elementor-widget-html" data-id="ca0392a" data-element_type="widget" data-widget_type="html.default">
                <div class="elementor-widget-container">
                    <div class="fontchuan-text-generator">
                        <textarea type="text" class="form-control textgenerator" maxlength="5000" required="required" name="text" placeholder="Nhập nội dung bạn muốn tạo Font đẹp vào đây..." value=""></textarea>
                        <br />
                        <div id="fc-contener-text-generator">
                            <div class="input-group fc-3">
                                <textarea class="form-control text-2" id="copy_1" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_1">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-6" id="copy_5" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_5">Copy</span></div>
                            </div>
                            <div class="input-group fc-3">
                                <textarea class="form-control text-45" id="copy_44" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_44">Copy</span></div>
                            </div>
                            <div class="input-group fc-3">
                                <textarea class="form-control text-27" id="copy_26" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_26">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-40" id="copy_39" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_39">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-41" id="copy_40" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_40">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-47" id="copy_46" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_46">Copy</span></div>
                            </div>
                            <div class="input-group fc-3">
                                <textarea class="form-control text-48" id="copy_47" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_47">Copy</span></div>
                            </div>
                            <div class="input-group fc-3">
                                <textarea class="form-control text-49" id="copy_48" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_48">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-29" id="copy_28" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_28">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-13" id="copy_12" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_12">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-61" id="copy_60" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_60">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-16" id="copy_15" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_15">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-15" id="copy_14" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_14">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-21" id="copy_20" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_20">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-31" id="copy_30" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_30">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-65" id="copy_64" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_64">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-72" id="copy_71" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_71">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-35" id="copy_34" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_34">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-37" id="copy_36" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_36">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-38" id="copy_37" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_37">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-81" id="copy_80" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_80">Copy</span></div>
                            </div>
                            <div class="input-group fc-3">
                                <textarea class="form-control text-82" id="copy_81" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_81">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-51" id="copy_50" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_50">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-8" id="copy_7" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_7">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-11" id="copy_10" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_10">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-52" id="copy_51" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_51">Copy</span></div>
                            </div>
                            <div class="input-group fc-3">
                                <textarea class="form-control text-53" id="copy_52" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_52">Copy</span></div>
                            </div>

                            <div class="input-group fc-3">
                                <textarea class="form-control text-56" id="copy_55" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_55">Copy</span></div>
                            </div>
                            <div class="input-group fc-3">
                                <textarea class="form-control text-57" id="copy_56" readonly="readonly" rows="1"></textarea>
                                <div class="input-group-append"><span class="input-group-text copybutton" style="cursor: pointer;" data-clipboard-action="copy" data-clipboard-target="#copy_56">Copy</span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
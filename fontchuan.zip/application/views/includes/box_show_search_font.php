<div class="elementor-element elementor-element-38c2af9 e-flex e-con-boxed e-con e-parent e-lazyloaded" data-id="38c2af9" data-element_type="container" data-settings='{"background_background":"classic"}'>
    <div class="e-con-inner">
        <div class="elementor-element elementor-element-e0af12e e-con-full e-flex e-con e-child" data-id="e0af12e" data-element_type="container" data-settings='{"background_background":"classic"}'>
            <div class="elementor-element elementor-element-b24451c elementor-widget elementor-widget-template" data-id="b24451c" data-element_type="widget" data-widget_type="template.default">
                <div class="elementor-widget-container">
                    <div class="elementor-template">
                        <div data-elementor-type="container" data-elementor-id="1780" class="elementor elementor-1780" data-elementor-post-type="elementor_library">
                            <div
                                class="elementor-element elementor-element-a4c9c66 e-flex e-con-boxed e-con e-parent e-lazyloaded"
                            >
                                <div class="e-con-inner">
                                    <div class="elementor-element elementor-element-502d76b e-con-full e-flex e-con e-child" data-id="502d76b" data-element_type="container" data-settings='{"background_background":"classic"}'>
                                        <div
                                            class="elementor-element elementor-element-3486918 elementor-widget elementor-widget-search"
                                            style="--e-search-icon-label-absolute-width: 0px; --e-search-icon-clear-absolute-width: 11px;"
                                        >
                                            <div class="elementor-widget-container">
                                                <search class="e-search" role="search">
                                                    <div class="e-search-form">
                                                        <label class="e-search-label" for="search-font">
                                                            <span class="elementor-screen-only"> Tìm kiếm </span>
                                                        </label>

                                                        <div class="e-search-input-wrapper">
                                                            <input
                                                                id="search-font"
                                                                placeholder="Nhập font bạn muốn tìm"
                                                                class="e-search-input no-icon-label"
                                                                type="search"
                                                                name="s"
                                                            />
                                                            <i aria-hidden="true" class="fas fa-times hidden"></i>  
                                                        </div>

                                                        <button class="e-search-submit" type="button">
                                                            <i aria-hidden="true" class="fas fa-search"></i>
                                                            <span class=""> </span>
                                                        </button>
                                                        <input type="hidden" name="e_search_props" value="3486918-1780" />
                                                    </div>
                                                </search>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="elementor-element elementor-element-8557dc4 elementor-widget elementor-widget-template" data-id="8557dc4" data-element_type="widget" data-widget_type="template.default" style="display:none">
                <div class="elementor-widget-container">
                    <div class="elementor-template">
                        <div data-elementor-type="section" data-elementor-id="16627" class="elementor elementor-16627" data-elementor-post-type="elementor_library">
                            <div
                                class="elementor-element elementor-element-c145b55 e-flex e-con-boxed e-con e-parent e-lazyloaded"
                            >
                                <div class="e-con-inner">
                                    <link
                                        data-minify="1"
                                        rel="stylesheet"
                                        id="jet-smart-filters-css"
                                        href="/assets/css/public.css?ver=<?=time()?>"
                                        type="text/css"
                                        media="all"
                                    />
                                    <style id="jet-smart-filters-inline-css" type="text/css">
                                        .jet-filter {
                                            --tabindex-color: #0085f2;
                                            --tabindex-shadow-color: rgba(0, 133, 242, 0.4);
                                        }
                                    </style>
                                    <div class="elementor-element elementor-element-c4e8a9e elementor-widget elementor-widget-jet-smart-filters-checkboxes">
                                        <div class="elementor-widget-container">
                                            <div class="jet-filters-group">
                                                <div class="jet-smart-filters-checkboxes jet-filter jet-filter-indexed" data-indexer-rule="disable" data-show-counter="yes" data-change-counter="never" jsf-filter="">
                                                    <div class="jet-checkboxes-list">
                                                        <fieldset class="jet-checkboxes-list-wrapper">
                                                            <div class="jet-checkboxes-list__row jet-filter-row">
                                                                <label class="jet-checkboxes-list__item" tabindex="0">
                                                                    <input type="checkbox" class="jet-checkboxes-list__input" name="loai-font" value="95" data-label="Font chữ Thư pháp" aria-label="Font chữ Thư pháp" />
                                                                    <div class="jet-checkboxes-list__button">
                                                                        <span class="jet-checkboxes-list__decorator">
                                                                            <i class="jet-checkboxes-list__checked-icon">
                                                                                <svg width="28" height="28" viewBox="0 0 28 28" xmlns="http://www.w3.org/2000/svg">
                                                                                    <path
                                                                                        d="M26.109 8.844c0 0.391-0.156 0.781-0.438 1.062l-13.438 13.438c-0.281 0.281-0.672 0.438-1.062 0.438s-0.781-0.156-1.062-0.438l-7.781-7.781c-0.281-0.281-0.438-0.672-0.438-1.062s0.156-0.781 0.438-1.062l2.125-2.125c0.281-0.281 0.672-0.438 1.062-0.438s0.781 0.156 1.062 0.438l4.594 4.609 10.25-10.266c0.281-0.281 0.672-0.438 1.062-0.438s0.781 0.156 1.062 0.438l2.125 2.125c0.281 0.281 0.438 0.672 0.438 1.062z"
                                                                                    ></path>
                                                                                </svg>
                                                                            </i>
                                                                        </span>
                                                                        <span class="jet-checkboxes-list__label">Font chữ Thư pháp</span>
                                                                        <span class="jet-filters-counter"><span class="counter-prefix">[</span><span class="value">34</span><span class="counter-suffix">]</span></span>
                                                                    </div>
                                                                </label>
                                                            </div>
                                                        </fieldset>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php $this->load->view('includes/box_show_search')?>
        </div>
    </div>
</div>
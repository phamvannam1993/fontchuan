<div id="mySidenav" class="sidenav menu_mobile hidden-md hidden-lg">
    <div class="top_menu_mobile">
    <span class="close_menu">
    </span>
    </div>
    <div class="content_memu_mb">
    <div class="link_list_mobile">
        <ul class="ct-mobile">
            <li class="level0 level-top level_ico">
                <a href="/lich-khai-giang">Lịch khai giảng</a>
            </li>
            <li class="level0 level-top level_ico">
                <a href="javascript:void(0)" class="parent">Giới thiệu</a>
                <i class="ti-plus hide_close"></i>
                <ul class="level0 sub-menu" style="display:none;background: rgb(28 35 98);">
                <li class="level1">
                    <a href="/tam-nhin-va-su-menh" title="Tầm nhìn và sứ mệnh">Tầm nhìn và sứ mệnh </a>
                </li>
                <li class="level1">
                    <a href="/gia-tri-cot-loi" title="Giá trị cốt lõi">Giá trị cốt lõi </a>
                </li>
                <li class="level1">
                    <a href="/so-do-to-chuc" title="Sơ đồ tổ chức">Sơ đồ tổ chức </a>
                </li>
                <li class="level1"class="level1">
                    <a href="/giang-vien" title="Giảng viên" style="margin: 10px 0px 0px;padding-bottom: 10px;">Giảng viên </a>
                </li>
                </ul>
            </li>
            <li class="level0 level-top level_ico">
                <a href="javascript:void(0)" class="parent">Khóa học</a>
                <i class="ti-plus hide_close"></i>
                <ul class="level0 sub-menu" style="display:none;background: rgb(28 35 98);">
                <li class="level1">
                    <a href="/khoa-hoc-danh-cho-giam-doc" style="margin: 10px 0px 0px;padding-bottom: 10px;"><span>Khóa học dành cho giám đốc</span></a>
                </li>
                <li class="level1">
                    <a href="/khoa-hoc-danh-cho-quan-ly" style="margin: 10px 0px 0px;padding-bottom: 10px;"><span>Khóa học dành cho quản lý</span></a>
                </li>
                <li class="level1">
                    <a href="/khoa-hoc-ngan-han" style="margin: 10px 0px 0px;padding-bottom: 10px;"><span>Khóa học ngắn hạn</span></a>
                </li>
                </ul>
            </li>
            <li class="level0 level-top parent level_ico">
                <a href="javascript:void(0)" class="parent">Khóa học online</a>
                <i class="ti-plus hide_close"></i>
                <ul class="level0 sub-menu" style="display:none;background: rgb(28 35 98);">
                <li class="level1">
                    <a href="javascript:void(0)" title="">Đào tạo online PEO </a>
                </li>
                <li class="level1">
                    <a href="javascript:void(0)" title="">Đào tạo online UNIVN </a>
                </li>
                <li class="level1">
                    <a href="javascript:void(0)" title="" style="margin: 10px 0px 0px;padding-bottom: 10px;">Đào tạo CEOONLINE </a>
                </li>
                </ul>
            </li>
            <li class="level0 level-top parent level_ico">
                <a href="/dao-tao-inhouse">Đào tạo inhouse</a>
            </li>
            <li class="level0 level-top parent level_ico">
                <a href="/tin-tuc">Tin tức</a>
            </li>
            <li class="level0 level-top parent level_ico">
                <a href="/lien-he">Liên hệ</a>
            </li>
        </ul>
    </div>
    </div>
</div>
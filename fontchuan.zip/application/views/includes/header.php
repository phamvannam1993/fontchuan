<div data-elementor-type="header" data-elementor-id="28" class="elementor elementor-28 elementor-location-header" data-elementor-post-type="elementor_library">
    <div class="elementor-element elementor-element-e8ea953 e-flex e-con-boxed e-con e-parent e-lazyloaded" data-id="e8ea953" data-element_type="container" data-settings='{"background_background":"classic"}'>
        <div class="e-con-inner">
            <div class="elementor-element elementor-element-2ec9801 e-con-full e-flex e-con e-child" data-id="2ec9801" data-element_type="container" data-settings='{"background_background":"classic"}'>
                <div
                    class="elementor-element elementor-element-277659c elementor-nav-menu--dropdown-none elementor-widget elementor-widget-nav-menu"
                    data-id="277659c"
                    data-element_type="widget"
                    data-settings='{"submenu_icon":{"value":"&lt;i class=\"\"&gt;&lt;\/i&gt;","library":""},"layout":"horizontal"}'
                    data-widget_type="nav-menu.default"
                >
                    <div class="elementor-widget-container">
                        <nav aria-label="Menu" class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-none">
                            <ul id="menu-1-277659c" class="elementor-nav-menu" data-smartmenus-id="17541231026872302">
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-358"><a href="/tao-kieu-chu-dep/" class="elementor-item">Tạo kiểu chữ đẹp</a></li>
                            </ul>
                        </nav>
                        <nav class="elementor-nav-menu--dropdown elementor-nav-menu__container" aria-hidden="true" style="--menu-height: 0;">
                            <ul id="menu-2-277659c" class="elementor-nav-menu" data-smartmenus-id="1754123102687445">
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-358"><a href="/tao-kieu-chu-dep/" class="elementor-item" tabindex="-1">Tạo kiểu chữ đẹp</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            <div class="elementor-element elementor-element-85c3c91 e-con-full e-flex e-con e-child" data-id="85c3c91" data-element_type="container">
                <div class="elementor-element elementor-element-2e60ab1 elementor-widget__width-auto ic elementor-widget elementor-widget-button" data-id="2e60ab1" data-element_type="widget" data-widget_type="button.default">
                    <div class="elementor-widget-container">
                        <div class="elementor-button-wrapper">
                            <a class="elementor-button elementor-button-link elementor-size-sm" href="/thanh-vien/" rel="nofollow">
                                <span class="elementor-button-content-wrapper">
                                    <span class="elementor-button-icon"> <i aria-hidden="true" class="fas fa-user-circle"></i> </span>
                                    <span class="elementor-button-text">Đăng nhập</span>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="elementor-element elementor-element-2fafa42 e-flex e-con-boxed e-con e-parent e-lazyloaded" data-id="2fafa42" data-element_type="container" id="backtotop" data-settings='{"background_background":"classic"}'>
        <div class="e-con-inner">
            <div class="elementor-element elementor-element-efbe230 e-con-full e-flex e-con e-child" data-id="efbe230" data-element_type="container" data-settings='{"background_background":"classic"}'>
                <div class="elementor-element elementor-element-38044ff logo elementor-widget elementor-widget-theme-site-logo elementor-widget-image" data-id="38044ff" data-element_type="widget" data-widget_type="theme-site-logo.default">
                    <div class="elementor-widget-container">
                        <a href="">
                            <img fetchpriority="high" width="499" height="164" src="/assets/images/logo-fontchuan-v1.png" class="attachment-full size-full wp-image-147" alt="Logo Font Chuẩn" />
                        </a>
                    </div>
                </div>
            </div>
            <div class="elementor-element elementor-element-08508bb e-con-full e-flex e-con e-child" data-id="08508bb" data-element_type="container">
                <div
                    class="elementor-element elementor-element-74d0b08 elementor-nav-menu--stretch elementor-nav-menu__align-end elementor-nav-menu--dropdown-tablet elementor-nav-menu__text-align-aside elementor-nav-menu--toggle elementor-nav-menu--burger elementor-widget elementor-widget-nav-menu"
                    data-id="74d0b08"
                    data-element_type="widget"
                    data-settings='{"full_width":"stretch","layout":"horizontal","submenu_icon":{"value":"&lt;i class=\"fas fa-caret-down\"&gt;&lt;\/i&gt;","library":"fa-solid"},"toggle":"burger"}'
                    data-widget_type="nav-menu.default"
                >
                    <div class="elementor-widget-container">
                        <nav class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-text e--animation-float">
                            <ul id="menu-1-74d0b08" class="elementor-nav-menu" data-smartmenus-id="17541231026872178">
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-55 current_page_item menu-item-306">
                                    <a href="/" aria-current="page" class="elementor-item elementor-item-active">Trang Chủ</a>
                                </li>
                                <li class="menu-item menu-item-type-taxonomy menu-item-object-danh-muc-font menu-item-has-children menu-item-1514">
                                    <a
                                        href="/font"
                                        class="elementor-item has-submenu"
                                    >
                                        Font<span class="sub-arrow"><i class="fas fa-caret-down"></i></span>
                                    </a>

                                    <ul
                                        class="sub-menu elementor-nav-menu--dropdown sm-nowrap"
                                        style="width: auto;top: auto; left: 0px; margin-left: 0px; margin-top: 0px; min-width: 10em; max-width: 1000px;"
                                    >
                                     <?php foreach($categories as $category) { ?>
                                        <li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children">
                                            <a class="elementor-sub-item has-submenu">
                                                <?=$category['name']?><span class="sub-arrow"><i class="fas fa-caret-down"></i></span>
                                            </a>
                                            <ul class="sub-menu elementor-nav-menu--dropdown">
                                                <?php foreach($category['items'] as $item) { ?>
                                                    <li class="menu-item menu-item-type-taxonomy menu-item-object-su-kien menu-item-3141"><a href="/<?=$item['slug']?>" class="elementor-sub-item"><?=$item['name']?></a></li>
                                                <?php } ?>
                                            </ul>
                                        </li>
                                        <?php } ?>
                                    </ul>
                                    
                                </li>
                                
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-310">
                                    <a href="/blog/" class="elementor-item has-submenu" id="sm-17541231026872178-11" aria-haspopup="true" aria-controls="sm-17541231026872178-12" aria-expanded="false">
                                        Blog<span class="sub-arrow"><i class="fas fa-caret-down"></i></span>
                                    </a>
                                    <ul class="sub-menu elementor-nav-menu--dropdown" id="sm-17541231026872178-12" role="group" aria-hidden="true" aria-labelledby="sm-17541231026872178-11" aria-expanded="false">
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-261"><a href="/blog/do-hoa/" class="elementor-sub-item">Đồ họa</a></li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-262"><a href="/blog/kien-thuc-font/" class="elementor-sub-item">Kiến thức Font</a></li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-260"><a href="/blog/tin-tuc/" class="elementor-sub-item">Tin tức</a></li>
                                        <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-16404"><a href="/blog/doi-tac/" class="elementor-sub-item">Đối tác</a></li>
                                    </ul>
                                </li>
                                <li class="menu-item menu-item-type-taxonomy menu-item-object-danh-muc-font menu-item-1060"><a href="/danh-muc-font/bo-suu-tap/" class="elementor-item">Bộ Sưu Tập</a></li>
                                <li class="menu-item menu-item-type-taxonomy menu-item-object-danh-muc-font menu-item-has-children menu-item-1062">
                                    <a
                                        href="/danh-muc-font/font-tieng-viet/"
                                        class="elementor-item has-submenu"
                                        id="sm-17541231026872178-13"
                                        aria-haspopup="true"
                                        aria-controls="sm-17541231026872178-14"
                                        aria-expanded="false"
                                    >
                                        Font Tiếng Việt<span class="sub-arrow"><i class="fas fa-caret-down"></i></span>
                                    </a>
                                    <ul class="sub-menu elementor-nav-menu--dropdown" id="sm-17541231026872178-14" role="group" aria-hidden="true" aria-labelledby="sm-17541231026872178-13" aria-expanded="false">
                                        <li class="menu-item menu-item-type-post_type menu-item-object-font menu-item-2826"><a href="/font/unicode/" class="elementor-sub-item">Tải Font Unicode Đầy Đủ</a></li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-font menu-item-2825"><a href="/font/vni/" class="elementor-sub-item">Tải Font VNI Trọn Bộ</a></li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-font menu-item-2827"><a href="/font/tcvn3/" class="elementor-sub-item">Tải bộ Font TCVN3 (ABC)</a></li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-font menu-item-2824"><a href="/font/vntime/" class="elementor-sub-item">Font VnTime Full</a></li>
                                        <li class="menu-item menu-item-type-post_type menu-item-object-font menu-item-2828"><a href="/font/font-full/" class="elementor-sub-item">Download Font Full Tiếng Việt</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                        <div class="elementor-menu-toggle" role="button" tabindex="0" aria-label="Menu Toggle" aria-expanded="false" style="">
                            <i aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--open fas fa-stream"></i><i aria-hidden="true" role="presentation" class="elementor-menu-toggle__icon--close eicon-close"></i>
                            <span class="elementor-screen-only">Menu</span>
                        </div>
                        <nav class="elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-text e--animation-float">
                            <ul id="menu-1-74d0b08" class="elementor-nav-menu" data-smartmenus-id="17541231026872178">
                                <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-55 current_page_item">
                                    <a href="/">Trang Chủ</a>
                                </li>
                                <li class="menu-item menu-item-type-taxonomy menu-item-object-danh-muc-font menu-item-has-children">
                                    <a href="/danh-muc-font/font-viet-hoa/" class="elementor-item has-submenu" aria-haspopup="true">Font Việt Hóa</a>
                                    <ul class="sub-menu">
                                        <li class="menu-item menu-item-has-children">
                                            <a href="#">Font Theo Sự Kiện</a>
                                            <ul class="sub-menu">
                                                <li class="menu-item"><a href="/su-kien/font-chu-tet/">Font chữ Tết</a></li>
                                                <li class="menu-item"><a href="/su-kien/font-le-hoi/">Font Lễ hội</a></li>
                                            </ul>
                                        </li>
                                        <li class="menu-item menu-item-has-children">
                                            <a href="#">Loại Font</a>
                                            <ul class="sub-menu">
                                                <li class="menu-item"><a href="/loai-font/font-sans-serif/">Font Sans-serif</a></li>
                                                <li class="menu-item"><a href="/loai-font/font-logo/">Font Logo</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li class="menu-item menu-item-type-taxonomy menu-item-object-danh-muc-font">
                                    <a href="/danh-muc-font/font-quoc-te/">Font Quốc Tế</a>
                                </li>
                            </ul>
                        </nav>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const menuItems = document.querySelectorAll('.menu-item-has-children');

    menuItems.forEach(item => {
        item.addEventListener('mouseenter', () => {
            const submenu = item.querySelector('.sub-menu');
            if (submenu) {
                submenu.style.display = 'block';
            }
        });

        item.addEventListener('mouseleave', () => {
            const submenu = item.querySelector('.sub-menu');
            if (submenu) {
                submenu.style.display = 'none';
            }
        });
    });
});

</script>
<style>
/* Ẩn tất cả submenu */
.sub-menu {
    opacity: 0;
    visibility: hidden;
    transform: translateY(10px);
    transition: all 0.3s ease;
    position: absolute;
    z-index: 99;
    background: #fff;
    padding: 10px;
    min-width: 200px;
}


.menu-item-has-children:hover > .sub-menu {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
}

/* Positioning menu */
.menu-item-has-children {
    position: relative;
}

.elementor-28 .elementor-element.elementor-element-74d0b08 .elementor-nav-menu--dropdown {
    margin-left:100%;
    margin-top:-45px
}
</style>
